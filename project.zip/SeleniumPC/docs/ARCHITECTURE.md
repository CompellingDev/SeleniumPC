# Architecture

```text
Selenium PC Android app
        |
        | explicit RUN_COMMAND permission
        v
Termux RunCommandService
        |
        +-- Termux:X11 server (:1)
        |
        +-- PRoot-Distro
              |
              +-- Debian 12 ARM64
                    |
                    +-- XFCE window manager
                    +-- Python virtual environment
                    +-- Selenium
                    +-- Chromium
                    +-- ChromeDriver
```

## Why this architecture

Android Chrome and Android WebView do not provide an ordinary desktop Linux windowing environment. Selenium PC therefore runs the browser, driver and Python process in the same Debian userland and presents the resulting X11 windows through Termux:X11.

Keeping Chromium and ChromeDriver in Debian's package manager also reduces version mismatch risk.

## Trust boundaries

- Selenium PC cannot run Termux commands until Android grants Termux's custom permission.
- Termux additionally requires `allow-external-apps=true`, which the user must enable inside Termux.
- The app sends only scripts bundled into the APK.
- Debian runs without Android root through PRoot.
- No remote control server is exposed.
