# Validation record

Validated on 2026-07-13:

- All bundled Termux/Linux scripts pass `bash -n`.
- AndroidManifest.xml and all Android resource XML files parse successfully.
- Java sources pass the Java parser stage; full Android compilation requires `android.jar` from an Android SDK.
- The project pins Android Gradle Plugin 8.9.2, compile SDK 35, Java 17, and Gradle 8.11.1 in CI.
- A GitHub Actions workflow builds and uploads the debug APK.

Not performed in this environment:

- Android SDK compilation.
- Installation on a physical Android device.
- Live Termux/X11 integration test.

Those tests require an Android SDK and an Android 8+ device with Termux and Termux:X11.
