# Selenium PC for Android

Selenium PC is an Android launcher for a real Debian ARM64 workstation running through Termux, PRoot-Distro and Termux:X11.

It does **not** automate an Android WebView. Inside the Linux desktop it runs:

- Python 3 and `pip`
- the official Selenium Python package
- Debian Chromium
- the matching Debian ChromeDriver
- an XFCE desktop displayed by Termux:X11
- visible, movable browser windows

## What is included

The Android app provides dependency checks, a guided security bridge setup, a resumable Debian/XFCE/Selenium installer, desktop start/stop controls, an interactive Linux shell, a visible Selenium demonstration, and a status check.

## Device requirements

- Android 8.0 or newer.
- An ARM64 device is strongly recommended.
- Several gigabytes of free storage.
- Enough memory for Android, XFCE and Chromium at the same time.
- Termux and Termux:X11 installed from compatible official sources.

## Build

Open the repository in Android Studio with JDK 17, or run:

```bash
gradle assembleDebug
```

The project uses Android Gradle Plugin 8.9.2 and Gradle 8.11.1. The debug APK will be created at `app/build/outputs/apk/debug/app-debug.apk`.

## First run

1. Install and open Termux once.
2. Install Termux:X11.
3. Open Selenium PC.
4. Tap **Enable the secure Termux bridge**. Paste the copied command into Termux and press Enter.
5. Return to Selenium PC and grant the Termux command permission.
6. Tap **Install Debian + desktop + Selenium** and keep the Termux session open.
7. Tap **Start desktop**, then open the Termux:X11 window.
8. Tap **Run visible Selenium demo**.

## Normal Selenium code

The generated demo is stored at `/home/pc/workspace/demo.py` inside Debian:

```python
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service

options = Options()
options.binary_location = "/usr/bin/chromium"
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--ozone-platform=x11")

driver = webdriver.Chrome(
    service=Service("/usr/bin/chromedriver"),
    options=options,
)
driver.get("https://example.com")
print(driver.title)
```

This opens a real visible Chromium window in the Linux desktop.

## Important boundary

This behaves like an ARM Linux PC, not like Windows. Native Windows `.exe` applications and x86-only binaries do not run directly. Selenium, Python, Chromium, Linux terminal tools, editors and ARM64 Linux packages are the intended workload.

PRoot is a user-space compatibility layer, so browser startup and package installation are slower than on a native Linux laptop.

## Troubleshooting

- **Black screen:** keep `-legacy-drawing` enabled in `start_desktop.sh`.
- **App cannot control Termux:** repeat bridge step 3 and grant the additional permission in Android app settings.
- **Browser fails after an update:** rerun the installer so Debian upgrades Chromium and ChromeDriver together.
- **Desktop already running:** tap Stop desktop, then Start desktop.
- **Installation interrupted:** run the installer again; package managers resume or reuse completed work.
- **See logs:** `~/selenium-pc-install.log` and `~/selenium-pc-x11.log` in Termux; `~/xfce-session.log` inside Debian.

## Security

The app only sends bundled scripts to Termux after Android grants `com.termux.permission.RUN_COMMAND` and the user explicitly enables external commands in Termux. Review all scripts under `app/src/main/assets/scripts/`.

## Version 0.2 fast-upgrade UX

- Installation now runs as a background Termux command instead of opening a blank terminal session.
- The app polls a small progress file and shows installation progress in the dashboard.
- Start Desktop automatically opens Termux:X11.
- Run Selenium Demo starts the browser and switches to the desktop window.
- Setup, launch actions, activity output, and troubleshooting are separated into clear cards.

### Upgrade an existing mobile build

Open this folder in AndroidIDE, keep your ARM64 AAPT2 override in `gradle.properties`, and run:

```bash
export JAVA_HOME="$HOME/.jdks/jdk-17"
export PATH="$JAVA_HOME/bin:$PATH"
./gradlew assembleDebug
```

Install the APK from `app/build/outputs/apk/debug/app-debug.apk`. Installing over version 0.1 keeps the same application data because the package name is unchanged.
