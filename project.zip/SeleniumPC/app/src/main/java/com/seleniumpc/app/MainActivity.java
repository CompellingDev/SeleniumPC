package com.seleniumpc.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQUEST_TERMUX_PERMISSION = 41;
    private static final long PROGRESS_POLL_MS = 4500L;
    private static final String PREFS = "selenium_pc";
    private static final String BRIDGE_COMMAND =
            "mkdir -p ~/.termux && " +
            "touch ~/.termux/termux.properties && " +
            "sed -i '/^allow-external-apps=/d' ~/.termux/termux.properties && " +
            "echo 'allow-external-apps=true' >> ~/.termux/termux.properties && " +
            "termux-reload-settings && echo 'Bridge enabled successfully'";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView dependencyStatus;
    private TextView heroStatus;
    private TextView progressText;
    private TextView commandStatus;
    private ProgressBar installProgress;
    private Button installButton;
    private Button startButton;

    private final Runnable progressPoll = new Runnable() {
        @Override public void run() {
            if (!isInstalling()) return;
            runScript("scripts/check_progress.sh", true, "__progress__", "Read installer progress", false);
            handler.postDelayed(this, PROGRESS_POLL_MS);
        }
    };

    private final BroadcastReceiver resultReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            refreshUiFromPreferences();
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildInterface();
    }

    @Override protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter(CommandResultService.ACTION_RESULT);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(resultReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(resultReceiver, filter);
        }
    }

    @Override protected void onStop() {
        super.onStop();
        unregisterReceiver(resultReceiver);
        handler.removeCallbacks(progressPoll);
    }

    @Override protected void onResume() {
        super.onResume();
        refreshDependencyStatus();
        refreshUiFromPreferences();
        if (isInstalling()) startProgressPolling();
    }

    private void buildInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(8, 13, 27));

        LinearLayout content = column();
        content.setPadding(dp(18), dp(22), dp(18), dp(42));
        scroll.addView(content);

        LinearLayout hero = card(Color.rgb(20, 31, 62));
        hero.setPadding(dp(20), dp(20), dp(20), dp(20));
        TextView title = text("Selenium PC", 30, Color.WHITE, true);
        hero.addView(title);
        TextView subtitle = text("Desktop Python automation on Android", 15, Color.rgb(185, 199, 236), false);
        subtitle.setPadding(0, dp(5), 0, dp(14));
        hero.addView(subtitle);
        heroStatus = text("Checking your workstation…", 14, Color.rgb(139, 230, 181), true);
        hero.addView(heroStatus);
        content.addView(hero);

        content.addView(section("QUICK SETUP"));
        dependencyStatus = text("", 14, Color.rgb(224, 231, 250), false);
        LinearLayout setupCard = card(Color.rgb(18, 27, 51));
        setupCard.addView(dependencyStatus);
        setupCard.addView(smallButton("Install/open Termux", v -> openUrl("https://github.com/termux/termux-app/releases")));
        setupCard.addView(smallButton("Install/open Termux:X11", v -> openUrl("https://github.com/termux/termux-x11/releases/tag/nightly")));
        setupCard.addView(smallButton("Enable secure bridge", v -> enableBridge()));
        setupCard.addView(smallButton("Grant control permission", v -> requestTermuxPermission()));
        content.addView(setupCard);

        content.addView(section("WORKSTATION"));
        LinearLayout installCard = card(Color.rgb(18, 27, 51));
        TextView installTitle = text("Linux PC environment", 20, Color.WHITE, true);
        installCard.addView(installTitle);
        TextView installDescription = text(
                "Installs Debian, XFCE, Python, Selenium, Chromium and ChromeDriver. Installation runs in the background.",
                14, Color.rgb(180, 193, 224), false);
        installDescription.setPadding(0, dp(5), 0, dp(14));
        installCard.addView(installDescription);
        installProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        installProgress.setIndeterminate(false);
        installProgress.setMax(100);
        installProgress.setProgress(0);
        installCard.addView(installProgress, new LinearLayout.LayoutParams(-1, dp(8)));
        progressText = text("Not installed yet", 13, Color.rgb(162, 176, 210), false);
        progressText.setPadding(0, dp(9), 0, dp(10));
        installCard.addView(progressText);
        installButton = primaryButton("Install workstation", v -> startInstallation());
        installCard.addView(installButton);
        content.addView(installCard);

        content.addView(section("LAUNCH"));
        LinearLayout launchGrid = column();
        startButton = primaryButton("Start desktop", v -> startDesktop());
        launchGrid.addView(startButton);
        launchGrid.addView(actionButton("Open desktop window", v -> openPackage(TermuxBridge.X11_PACKAGE)));
        launchGrid.addView(actionButton("Run Selenium demo", v -> {
            runScript("scripts/run_demo.sh", true, "Selenium demo", "Launch visible Chromium demo", true);
            handler.postDelayed(() -> openPackage(TermuxBridge.X11_PACKAGE), 1800);
        }));
        launchGrid.addView(actionButton("Open Linux shell", v -> runScript(
                "scripts/open_shell.sh", false, "Linux shell", "Interactive Debian shell", true)));
        content.addView(launchGrid);

        content.addView(section("ACTIVITY"));
        commandStatus = panelText("Nothing running yet.");
        content.addView(commandStatus);

        TextView troubleshooting = text("Troubleshooting", 14, Color.rgb(131, 159, 255), true);
        troubleshooting.setPadding(dp(3), dp(22), dp(3), dp(12));
        troubleshooting.setOnClickListener(v -> showTroubleshooting());
        content.addView(troubleshooting);

        setContentView(scroll);
    }

    private void startInstallation() {
        if (!preflight()) return;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("installing", true)
                .putString("install_progress", "5|Preparing installer")
                .apply();
        refreshUiFromPreferences();
        runScript("scripts/install_pc.sh", true, "Install workstation", "Background Linux workstation installer", true);
        startProgressPolling();
    }

    private void startDesktop() {
        if (!preflight()) return;
        runScript("scripts/start_desktop.sh", true, "Start desktop", "Start XFCE and X11", true);
        heroStatus.setText("Starting desktop…");
        handler.postDelayed(() -> openPackage(TermuxBridge.X11_PACKAGE), 2400);
    }

    private void startProgressPolling() {
        handler.removeCallbacks(progressPoll);
        handler.postDelayed(progressPoll, 1200);
    }

    private boolean isInstalling() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("installing", false);
    }

    private void refreshDependencyStatus() {
        boolean termux = TermuxBridge.isInstalled(this, TermuxBridge.TERMUX_PACKAGE);
        boolean x11 = TermuxBridge.isInstalled(this, TermuxBridge.X11_PACKAGE);
        boolean permission = checkSelfPermission(TermuxBridge.RUN_PERMISSION) == PackageManager.PERMISSION_GRANTED;

        dependencyStatus.setText(
                statusLine("Termux", termux) + "\n" +
                statusLine("Termux:X11", x11) + "\n" +
                statusLine("Control permission", permission)
        );

        if (termux && x11 && permission) {
            heroStatus.setText(isInstalling() ? "Installing your workstation…" : "Device bridge ready");
        } else {
            heroStatus.setText("Complete quick setup below");
        }
    }

    private String statusLine(String label, boolean ready) {
        return (ready ? "✓  " : "○  ") + label + (ready ? " ready" : " needed");
    }

    private void refreshUiFromPreferences() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        commandStatus.setText(prefs.getString("last_result", "Nothing running yet."));
        String raw = prefs.getString("install_progress", "0|Not installed yet");
        String[] parts = raw.split("\\|", 2);
        int percent = 0;
        try { percent = Integer.parseInt(parts[0]); } catch (Exception ignored) {}
        String message = parts.length > 1 ? parts[1] : "Working…";
        installProgress.setProgress(Math.max(0, Math.min(100, percent)));
        progressText.setText(percent + "%  •  " + message);

        boolean installing = prefs.getBoolean("installing", false);
        installButton.setEnabled(!installing);
        installButton.setText(installing ? "Installing in background…" : (percent >= 100 ? "Repair / update workstation" : "Install workstation"));
        startButton.setEnabled(!installing && percent >= 100);
        if (percent >= 100) heroStatus.setText("Workstation ready");
    }

    private boolean preflight() {
        if (!TermuxBridge.isInstalled(this, TermuxBridge.TERMUX_PACKAGE)) {
            toast("Install Termux first."); return false;
        }
        if (checkSelfPermission(TermuxBridge.RUN_PERMISSION) != PackageManager.PERMISSION_GRANTED) {
            requestTermuxPermission(); return false;
        }
        return true;
    }

    private void enableBridge() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Termux bridge command", BRIDGE_COMMAND));
        new AlertDialog.Builder(this)
                .setTitle("One-time bridge setup")
                .setMessage("The command is copied. Tap Open Termux, paste it, press Enter, then return here. You only do this once.")
                .setPositiveButton("Open Termux", (dialog, which) -> openPackage(TermuxBridge.TERMUX_PACKAGE))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void requestTermuxPermission() {
        if (!TermuxBridge.isInstalled(this, TermuxBridge.TERMUX_PACKAGE)) {
            toast("Install and open Termux first."); return;
        }
        if (checkSelfPermission(TermuxBridge.RUN_PERMISSION) == PackageManager.PERMISSION_GRANTED) {
            toast("Control permission is already enabled."); return;
        }
        requestPermissions(new String[]{TermuxBridge.RUN_PERMISSION}, REQUEST_TERMUX_PERMISSION);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_TERMUX_PERMISSION) {
            refreshDependencyStatus();
            if (grantResults.length == 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                new AlertDialog.Builder(this)
                        .setTitle("Permission needed")
                        .setMessage("Open Selenium PC permissions and enable “Run commands in Termux environment”.")
                        .setPositiveButton("Open settings", (d, w) -> openOwnSettings())
                        .setNegativeButton("Later", null).show();
            }
        }
    }

    private void runScript(String asset, boolean background, String label, String description, boolean showStatus) {
        if (!preflight()) return;
        try {
            String script = readAsset(asset);
            if (showStatus) commandStatus.setText(label + " started…");
            TermuxBridge.runBash(this, script, background, label, description);
        } catch (SecurityException e) {
            commandStatus.setText("Termux rejected the command. Re-enable the bridge and permission.");
        } catch (Exception e) {
            commandStatus.setText("Could not start: " + e.getMessage());
        }
    }

    private String readAsset(String path) throws IOException {
        try (InputStream input = getAssets().open(path); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int count;
            while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            return output.toString(StandardCharsets.UTF_8.name());
        }
    }

    private void showTroubleshooting() {
        new AlertDialog.Builder(this)
                .setTitle("Troubleshooting")
                .setItems(new String[]{"Check installation", "Stop desktop", "Open Termux", "Open app settings"}, (d, which) -> {
                    if (which == 0) runScript("scripts/check_status.sh", true, "System check", "Check workstation", true);
                    if (which == 1) runScript("scripts/stop_desktop.sh", true, "Stop desktop", "Stop XFCE and X11", true);
                    if (which == 2) openPackage(TermuxBridge.TERMUX_PACKAGE);
                    if (which == 3) openOwnSettings();
                }).show();
    }

    private void openPackage(String packageName) {
        Intent intent = getPackageManager().getLaunchIntentForPackage(packageName);
        if (intent == null) { toast(packageName + " is not installed."); return; }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(intent);
    }

    private void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { toast("Could not open the download page."); }
    }

    private void openOwnSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(Uri.parse("package:" + getPackageName())); startActivity(intent);
    }

    private LinearLayout column() {
        LinearLayout view = new LinearLayout(this);
        view.setOrientation(LinearLayout.VERTICAL);
        view.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        return view;
    }

    private LinearLayout card(int color) {
        LinearLayout view = column();
        view.setPadding(dp(16), dp(16), dp(16), dp(16));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color); bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), Color.rgb(39, 52, 87));
        view.setBackground(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 0, 0, dp(12)); view.setLayoutParams(p);
        return view;
    }

    private TextView section(String value) {
        TextView view = text(value, 12, Color.rgb(124, 156, 255), true);
        view.setLetterSpacing(.09f); view.setPadding(dp(3), dp(21), 0, dp(9));
        return view;
    }

    private Button primaryButton(String value, View.OnClickListener listener) {
        return styledButton(value, Color.rgb(84, 112, 235), listener);
    }

    private Button actionButton(String value, View.OnClickListener listener) {
        return styledButton(value, Color.rgb(28, 40, 75), listener);
    }

    private Button smallButton(String value, View.OnClickListener listener) {
        Button b = styledButton(value, Color.rgb(28, 40, 75), listener);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(48));
        p.setMargins(0, dp(7), 0, 0); b.setLayoutParams(p); return b;
    }

    private Button styledButton(String value, int color, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(value); b.setAllCaps(false); b.setTextSize(15); b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable(); bg.setColor(color); bg.setCornerRadius(dp(14));
        b.setBackground(bg); b.setOnClickListener(listener);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54));
        p.setMargins(0, 0, 0, dp(10)); b.setLayoutParams(p); return b;
    }

    private TextView panelText(String initial) {
        TextView v = text(initial, 13, Color.rgb(218, 226, 246), false);
        v.setTextIsSelectable(true); v.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.rgb(16, 24, 47)); bg.setCornerRadius(dp(14));
        v.setBackground(bg); return v;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(value); v.setTextSize(sp); v.setTextColor(color);
        v.setLineSpacing(0, 1.16f); if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return v;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
}
