package com.seleniumpc.app;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import java.util.concurrent.atomic.AtomicInteger;

final class TermuxBridge {
    static final String TERMUX_PACKAGE = "com.termux";
    static final String X11_PACKAGE = "com.termux.x11";
    static final String RUN_PERMISSION = "com.termux.permission.RUN_COMMAND";

    private static final String RUN_SERVICE = "com.termux.app.RunCommandService";
    private static final String ACTION_RUN = "com.termux.RUN_COMMAND";
    private static final String EXTRA_PATH = "com.termux.RUN_COMMAND_PATH";
    private static final String EXTRA_ARGS = "com.termux.RUN_COMMAND_ARGUMENTS";
    private static final String EXTRA_STDIN = "com.termux.RUN_COMMAND_STDIN";
    private static final String EXTRA_WORKDIR = "com.termux.RUN_COMMAND_WORKDIR";
    private static final String EXTRA_BACKGROUND = "com.termux.RUN_COMMAND_BACKGROUND";
    private static final String EXTRA_SESSION_ACTION = "com.termux.RUN_COMMAND_SESSION_ACTION";
    private static final String EXTRA_LABEL = "com.termux.RUN_COMMAND_COMMAND_LABEL";
    private static final String EXTRA_DESCRIPTION = "com.termux.RUN_COMMAND_COMMAND_DESCRIPTION";
    private static final String EXTRA_PENDING_INTENT = "com.termux.RUN_COMMAND_PENDING_INTENT";

    private static final String BASH = "/data/data/com.termux/files/usr/bin/bash";
    private static final String HOME = "/data/data/com.termux/files/home";
    private static final AtomicInteger EXECUTION_IDS = new AtomicInteger(1000);

    private TermuxBridge() {}

    static boolean isInstalled(Context context, String packageName) {
        try {
            context.getPackageManager().getPackageInfo(packageName, 0);
            return true;
        } catch (PackageManager.NameNotFoundException ignored) {
            return false;
        }
    }

    static void runBash(
            Context context,
            String script,
            boolean background,
            String label,
            String description
    ) {
        int executionId = EXECUTION_IDS.incrementAndGet();

        Intent resultIntent = new Intent(context, CommandResultService.class);
        resultIntent.putExtra(CommandResultService.EXTRA_EXECUTION_ID, executionId);
        resultIntent.putExtra(CommandResultService.EXTRA_LABEL, label);

        int flags = PendingIntent.FLAG_ONE_SHOT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            flags |= PendingIntent.FLAG_MUTABLE;
        }
        PendingIntent resultPendingIntent = PendingIntent.getService(
                context,
                executionId,
                resultIntent,
                flags
        );

        Intent command = new Intent();
        command.setClassName(TERMUX_PACKAGE, RUN_SERVICE);
        command.setAction(ACTION_RUN);
        command.putExtra(EXTRA_PATH, BASH);
        command.putExtra(EXTRA_ARGS, new String[]{"-s"});
        command.putExtra(EXTRA_STDIN, script);
        command.putExtra(EXTRA_WORKDIR, HOME);
        command.putExtra(EXTRA_BACKGROUND, background);
        command.putExtra(EXTRA_SESSION_ACTION, "0");
        command.putExtra(EXTRA_LABEL, label);
        command.putExtra(EXTRA_DESCRIPTION, description);
        command.putExtra(EXTRA_PENDING_INTENT, resultPendingIntent);

        context.startService(command);
    }
}
