package com.seleniumpc.app;

import android.app.IntentService;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

@SuppressWarnings("deprecation")
public class CommandResultService extends IntentService {
    static final String EXTRA_EXECUTION_ID = "execution_id";
    static final String EXTRA_LABEL = "command_label";
    static final String ACTION_RESULT = "com.seleniumpc.app.COMMAND_RESULT";

    private static final String RESULT_BUNDLE = "result";
    private static final String STDOUT = "stdout";
    private static final String STDERR = "stderr";
    private static final String EXIT_CODE = "exitCode";
    private static final String ERROR_MESSAGE = "errmsg";

    public CommandResultService() { super("SeleniumPcCommandResults"); }

    @Override protected void onHandleIntent(Intent intent) {
        if (intent == null) return;
        Bundle result = intent.getBundleExtra(RESULT_BUNDLE);
        String label = intent.getStringExtra(EXTRA_LABEL);
        if (label == null) label = "Command";

        String stdout = result == null ? "" : result.getString(STDOUT, "").trim();
        String stderr = result == null ? "" : result.getString(STDERR, "").trim();
        String error = result == null ? "" : result.getString(ERROR_MESSAGE, "").trim();
        int exitCode = result == null ? -999 : result.getInt(EXIT_CODE, -999);

        SharedPreferences prefs = getSharedPreferences("selenium_pc", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        if ("__progress__".equals(label)) {
            if (!stdout.isEmpty()) {
                editor.putString("install_progress", stdout);
                if (stdout.startsWith("100|")) editor.putBoolean("installing", false);
                if (stdout.startsWith("-1|")) editor.putBoolean("installing", false);
            }
        } else {
            StringBuilder text = new StringBuilder(label)
                    .append(exitCode == 0 ? " completed." : " finished with exit code " + exitCode + ".");
            if (!stdout.isEmpty()) text.append("\n\n").append(stdout);
            if (!stderr.isEmpty()) text.append("\n\nError output:\n").append(stderr);
            if (!error.isEmpty()) text.append("\n\nTermux error:\n").append(error);
            editor.putString("last_result", text.toString());

            if ("Install workstation".equals(label)) {
                editor.putBoolean("installing", false);
                if (exitCode == 0) editor.putString("install_progress", "100|Workstation installed successfully");
                else editor.putString("install_progress", "-1|Installation stopped — open Activity for details");
            }
        }

        editor.apply();
        Intent update = new Intent(ACTION_RESULT);
        update.setPackage(getPackageName());
        sendBroadcast(update);
    }
}
