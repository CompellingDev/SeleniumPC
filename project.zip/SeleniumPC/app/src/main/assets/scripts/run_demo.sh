#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail

if ! proot-distro list -q 2>/dev/null | grep -qx 'seleniumpc'; then
  echo "Selenium PC is not installed. Run the installer first."
  exit 1
fi

if ! pgrep -f 'termux-x11 :1' >/dev/null 2>&1; then
  mkdir -p "$PREFIX/tmp/.X11-unix"
  termux-x11 :1 -legacy-drawing >"$HOME/selenium-pc-x11.log" 2>&1 &
  sleep 2
fi

exec proot-distro login \
  --user pc \
  --shared-tmp \
  --shared-x11 \
  --env DISPLAY=:1 \
  --env XDG_RUNTIME_DIR=/tmp/runtime-pc \
  seleniumpc -- bash -lc '
    mkdir -p /tmp/runtime-pc
    chmod 700 /tmp/runtime-pc
    source /home/pc/.venv/bin/activate
    cd /home/pc/workspace
    export DISPLAY=:1
    export XDG_RUNTIME_DIR=/tmp/runtime-pc
    python demo.py
  '
