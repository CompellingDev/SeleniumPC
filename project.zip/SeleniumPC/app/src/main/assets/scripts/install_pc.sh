#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail

LOG="$HOME/selenium-pc-install.log"
STATE_DIR="$HOME/.selenium-pc"
PROGRESS="$STATE_DIR/progress"
mkdir -p "$STATE_DIR"
progress() { printf '%s|%s\n' "$1" "$2" > "$PROGRESS"; }
trap 'progress -1 "Installation failed. Check the activity log."' ERR
progress 5 "Preparing installer"
exec > >(tee -a "$LOG") 2>&1

banner() {
  printf '\n============================================================\n%s\n============================================================\n' "$1"
}

banner "Selenium PC installer"
echo "Log: $LOG"
echo "This installer is resumable. Run it again after an interrupted download."

progress 10 "Updating Termux packages"
banner "Updating Termux"
pkg update -y
pkg upgrade -y

progress 22 "Installing Linux and X11 tools"
banner "Installing the Android-side Linux and X11 tools"
pkg install -y x11-repo
pkg install -y termux-x11-nightly proot-distro pulseaudio

progress 38 "Installing Debian base system"
banner "Installing Debian 12 (Bookworm)"
if proot-distro list -q 2>/dev/null | grep -qx 'seleniumpc'; then
  echo "The seleniumpc container already exists; reusing it."
else
  proot-distro install debian:bookworm --name seleniumpc
fi

progress 55 "Installing desktop, Chromium and Python"
banner "Installing XFCE, Chromium, ChromeDriver and Python"
proot-distro login seleniumpc --shared-tmp --shared-x11 -- bash -lc '
set -Eeuo pipefail
export DEBIAN_FRONTEND=noninteractive

cat >/usr/sbin/policy-rc.d <<"POLICY"
#!/bin/sh
exit 101
POLICY
chmod +x /usr/sbin/policy-rc.d

apt-get update
apt-get install -y --no-install-recommends \
  xfce4 xfce4-terminal dbus-x11 \
  chromium chromium-driver \
  python3 python3-pip python3-venv \
  git curl wget nano ca-certificates \
  fonts-liberation fonts-dejavu-core \
  procps psmisc xdg-utils

if ! id pc >/dev/null 2>&1; then
  useradd -m -s /bin/bash pc
fi

rm -rf /home/pc/.venv
python3 -m venv /home/pc/.venv
/home/pc/.venv/bin/pip install --upgrade pip wheel
/home/pc/.venv/bin/pip install --upgrade selenium

mkdir -p \
  /home/pc/workspace \
  /home/pc/Desktop \
  /home/pc/.config/xfce4 \
  /home/pc/.cache \
  /tmp/runtime-pc

cat >/home/pc/workspace/demo.py <<"PYTHON_DEMO"
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service

profile = Path.home() / ".selenium-chromium"
profile.mkdir(exist_ok=True)

options = Options()
options.binary_location = "/usr/bin/chromium"
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--disable-gpu")
options.add_argument("--ozone-platform=x11")
options.add_argument("--start-maximized")
options.add_argument("--no-first-run")
options.add_argument("--no-default-browser-check")
options.add_argument("--password-store=basic")
options.add_argument(f"--user-data-dir={profile}")

driver = webdriver.Chrome(
    service=Service("/usr/bin/chromedriver"),
    options=options,
)
driver.get("https://www.selenium.dev/selenium/web/web-form.html")
print("Browser title:", driver.title)
print("A real Chromium window is now controlled by Python Selenium.")
input("Press Enter in this terminal to close the browser...")
driver.quit()
PYTHON_DEMO

cat >/home/pc/Desktop/Selenium-Demo.desktop <<"DESKTOP_DEMO"
[Desktop Entry]
Type=Application
Name=Selenium Browser Demo
Comment=Open a real Chromium window controlled by Python Selenium
Exec=xfce4-terminal --hold -e "bash -lc '\''source /home/pc/.venv/bin/activate; cd /home/pc/workspace; python demo.py'\''"
Icon=chromium
Terminal=false
Categories=Development;
DESKTOP_DEMO

cat >/home/pc/Desktop/Python-Terminal.desktop <<"DESKTOP_TERMINAL"
[Desktop Entry]
Type=Application
Name=Python Selenium Terminal
Comment=Terminal with the Selenium Python environment activated
Exec=xfce4-terminal --working-directory=/home/pc/workspace -e "bash -lc '\''source /home/pc/.venv/bin/activate; exec bash'\''"
Icon=utilities-terminal
Terminal=false
Categories=Development;
DESKTOP_TERMINAL

chmod +x /home/pc/Desktop/*.desktop

cat >/home/pc/.bashrc <<"BASHRC"
# Selenium PC environment
[ -f /etc/bash.bashrc ] && . /etc/bash.bashrc
export DISPLAY="${DISPLAY:-:1}"
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/tmp/runtime-pc}"
export PATH="/home/pc/.venv/bin:$PATH"
cd /home/pc/workspace 2>/dev/null || true
BASHRC

chown -R pc:pc /home/pc /tmp/runtime-pc
chmod 700 /tmp/runtime-pc
rm -f /usr/sbin/policy-rc.d

printf "\nInstalled versions:\n"
chromium --version
chromedriver --version
/home/pc/.venv/bin/python --version
/home/pc/.venv/bin/python -c "import selenium; print(\"Selenium\", selenium.__version__)"
'

progress 95 "Finishing setup"
banner "Setup complete"
echo "Return to Selenium PC, tap Start desktop, and then tap Run visible Selenium demo."
echo "Your Linux files are stored persistently in the seleniumpc container."
progress 100 "Workstation installed successfully"
