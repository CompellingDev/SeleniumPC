#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail

printf 'Termux X11 package: '
command -v termux-x11 >/dev/null && echo ready || echo missing

printf 'PRoot-Distro: '
command -v proot-distro >/dev/null && proot-distro --version 2>/dev/null | head -1 || echo missing

if ! proot-distro list -q 2>/dev/null | grep -qx 'seleniumpc'; then
  echo "Debian container: missing"
  exit 1
fi

echo "Debian container: ready"
proot-distro login seleniumpc --shared-tmp --shared-x11 -- bash -lc '
set -e
printf "Chromium: "
chromium --version
printf "ChromeDriver: "
chromedriver --version
printf "Python: "
/home/pc/.venv/bin/python --version
printf "Selenium: "
/home/pc/.venv/bin/python -c "import selenium; print(selenium.__version__)"
'
