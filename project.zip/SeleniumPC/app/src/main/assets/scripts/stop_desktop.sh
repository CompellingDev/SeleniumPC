#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail

proot-distro kill seleniumpc >/dev/null 2>&1 || true
pkill -f 'termux-x11 :1' >/dev/null 2>&1 || true
pulseaudio -k >/dev/null 2>&1 || true

echo "Selenium PC desktop stopped."
