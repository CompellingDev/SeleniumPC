#!/data/data/com.termux/files/usr/bin/bash
PROGRESS="$HOME/.selenium-pc/progress"
if [ -f "$PROGRESS" ]; then
  cat "$PROGRESS"
else
  echo '0|Waiting to start'
fi
