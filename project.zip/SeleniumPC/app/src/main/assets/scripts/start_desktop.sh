#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail

if ! proot-distro list -q 2>/dev/null | grep -qx 'seleniumpc'; then
  echo "Selenium PC is not installed. Run the installer first."
  exit 1
fi

mkdir -p "$PREFIX/tmp/.X11-unix"
proot-distro kill seleniumpc >/dev/null 2>&1 || true
pkill -f 'termux-x11 :1' >/dev/null 2>&1 || true
pulseaudio --start --exit-idle-time=-1 >/dev/null 2>&1 || true

termux-x11 :1 -legacy-drawing >"$HOME/selenium-pc-x11.log" 2>&1 &
sleep 2

proot-distro login \
  --user pc \
  --shared-tmp \
  --shared-x11 \
  --detach \
  --env DISPLAY=:1 \
  --env XDG_RUNTIME_DIR=/tmp/runtime-pc \
  seleniumpc -- bash -lc '
    mkdir -p /tmp/runtime-pc
    chmod 700 /tmp/runtime-pc
    export DISPLAY=:1
    export XDG_RUNTIME_DIR=/tmp/runtime-pc
    dbus-launch --exit-with-session startxfce4 >"$HOME/xfce-session.log" 2>&1
  '

echo "Desktop started on display :1."
echo "Open the Termux:X11 Android app to see the Linux desktop."
