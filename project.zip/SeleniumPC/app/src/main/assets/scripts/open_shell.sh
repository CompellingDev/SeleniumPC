#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail

if ! proot-distro list -q 2>/dev/null | grep -qx 'seleniumpc'; then
  echo "Selenium PC is not installed. Run the installer first."
  exit 1
fi

exec proot-distro login \
  --user pc \
  --shared-tmp \
  --shared-x11 \
  --env DISPLAY=:1 \
  --env XDG_RUNTIME_DIR=/tmp/runtime-pc \
  seleniumpc -- bash -lc '
    source /home/pc/.venv/bin/activate
    cd /home/pc/workspace
    echo "Python Selenium environment activated."
    echo "Try: python demo.py"
    exec bash -l
  '
